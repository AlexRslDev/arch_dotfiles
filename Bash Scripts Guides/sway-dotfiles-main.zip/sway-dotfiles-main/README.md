# dotfiles

My Rice Dotfiles [Arch + Sway]

## Installation

**1. Run "enable_multilib.sh" script as root.**

**2. Run "install_core.sh" script as root.**

**3. Run "install_aur_yay_apps.sh" script as root.**

**4. Run "install_flathub_apps.sh" script as root.**

**5. Run "install_terminal.sh" script as root.**

## TODO

- Integrate scratpatch into waybar
