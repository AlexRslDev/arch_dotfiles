return {
  {
    "sainnhe/everforest",
    lazy = true,
    config = function()
      vim.g.everforest_background = "medium" -- soft | medium | hard
      vim.g.everforest_enable_italic = 0
      vim.g.everforest_transparent_background = 0
    end,
  },
}
